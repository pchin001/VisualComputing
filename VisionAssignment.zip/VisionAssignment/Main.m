folder = 'imgset1/';
imgs = ['DSCF4177';
        'DSCF4179';
        'DSCF4183';
        'DSCF4186';
        'DSCF4188';
        'DSCF4192';];

param1 = strcat(folder, imgs(1, :), '.jpg');
param2 = strcat(folder, imgs(2, :), '.jpg');
EpipolarLine(param1, param2); 
% imgs --> list of filenames of imgs
% for j = 1:length(imgs) 
%     load_file = strcat('imgset1/', imgs(j, :), '.jpg');
%     imshow(load_file);
%     data = ginput(8); 
%     save_file = strcat(folder, imgs(j, :));
%     save(save_file, 'data'); 
% end