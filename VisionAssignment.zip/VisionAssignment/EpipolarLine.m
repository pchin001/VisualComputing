function [ ] = EpipolarLine(img1, img2)
%EPIPOLARLINE computes epipolar lines 
%   takes in a point from img1 and computers epipolar lines in img2 based
%   on that point

%% retrieve points from img1  
figure; imshow(img1);
pts1 = zeros(8, 2); 
for j = 1: length(pts1)
    [pts1(j, 1), pts1(j, 2)] = ginput(1);
    % label the points retrieved from ginput
    text(pts1(j, 1), pts1(j, 2), num2str(j));  
end

%% retrieve corresponding points from img2
figure; imshow(img2); 
pts2 = zeros(8, 2); 
for j = 1: length(pts2)
    [pts2(j, 1), pts2(j, 2)] = ginput(1);
    % label the points retrieved from ginput
    text(pts2(j, 1), pts2(j, 2), num2str(j));  
end

%% compute fundamental matrix 
F = estimateFundamentalMatrix(pts1, pts2);
end